import fetch from "node-fetch";
import dotenv from "dotenv";

dotenv.config();

// URL твоего FastAPI микросервиса
const SEARCH_API_URL = (process.env.SEARCH_API_URL || "http://localhost:8000").replace(/\/$/, "");

function detectLanguage(text) {
  if (/[а-яёәіңғүұқөһ]/i.test(text)) return "kazakh_or_russian";
  if (/[a-z]/i.test(text)) return "english";
  return "russian";
}

// Получаем релевантные документы из FastAPI
async function searchKnowledge(question, topN = 3) {
  try {
    const res = await fetch(`${SEARCH_API_URL}/search`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: question, top_n: topN }),
    });

    if (!res.ok) {
      console.error("❌ Search API error:", res.status);
      return null;
    }

    const data = await res.json();
    return data.results; // [{ title, body, similarity }]
  } catch (err) {
    console.error("❌ Search API недоступен:", err.message);
    return null;
  }
}

// Форматируем найденные документы в контекст для LLM
function formatContext(results) {
  if (!results || results.length === 0) return "База знаний недоступна.";

  return results
    .map((r, i) => `[${i + 1}] ${r.title}\n${r.body}`)
    .join("\n\n---\n\n");
}

export async function askZere(question) {
  const lang = detectLanguage(question);

  // 1. Ищем релевантные документы через векторный поиск
  console.log("🔍 Ищем в базе знаний...");
  const searchResults = await searchKnowledge(question, 3);

  if (searchResults) {
    console.log(
      `✅ Найдено ${searchResults.length} документов:`,
      searchResults.map((r) => `"${r.title}" (${(r.similarity * 100).toFixed(1)}%)`)
    );
  } else {
    console.log("⚠️ Векторный поиск недоступен, работаем без контекста");
  }

  // 2. Формируем контекст только из релевантных кусков
  const context = formatContext(searchResults);

  // 3. Запрос к Groq с компактным контекстом
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
      "Content-Type": "application/json",
    },
body: JSON.stringify({
  model: "llama-3.3-70b-versatile",
  max_tokens: 1000,
  messages: [
    {
      role: "system",
      content: `Ты — университетский ассистент Zere.
Отвечай ТОЛЬКО на основе базы знаний ниже.
Если в базе знаний есть хоть какая-то связанная информация — используй её и дай развёрнутый ответ.
Только если информации совсем нет — пиши: "В базе знаний нет информации по этому вопросу 😊"
На вопросы не по университету отвечай: "Извините, я могу помогать только по вопросам университета."
Используй язык вопроса: казахский → казахский, русский → русский, английский → английский.

База знаний:
${context}`.trim(),
    },
    { role: "user", content: question },
  ],
}),
  });

  const data = await response.json();

  console.log("\n🌐 Статус Groq API:", response.status);
  if (!response.ok) {
    console.error("❌ Ошибка от Groq API:", data);
    return "Ошибка при обращении к Groq API. Проверь ключ или модель.";
  }

  if (!data?.choices?.length) {
    console.error("⚠️ Пустой ответ от Groq API:", data);
    return "Groq API не вернул содержимого.";
  }

  const content = data.choices[0].message.content || "Ответ не получен.";

  // Убираем внутренние мысли модели если есть
  const thoughtsMatch = content.match(/\[Думает:(.*?)\]/s);
  if (thoughtsMatch) {
    console.log("\n💭 Мысли модели:", thoughtsMatch[1].trim());
  }

  const finalAnswer = content.replace(/\[Думает:.*?\]/s, "").trim();
  console.log("\n🧠 Ответ Zere:\n", finalAnswer);
  console.log("🔑 API Key:", process.env.GROQ_API_KEY ? "✅ найден" : "❌ отсутствует");

  return finalAnswer;
}